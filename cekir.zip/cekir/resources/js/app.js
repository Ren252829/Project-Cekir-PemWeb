import './bootstrap';
alert('hello world');